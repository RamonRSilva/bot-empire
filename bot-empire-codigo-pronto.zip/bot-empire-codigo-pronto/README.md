# Bot Empire: Four Kingdoms

Projeto de automação em nuvem para Empire: Four Kingdoms rodando via Node.js e WebSockets no Render.
